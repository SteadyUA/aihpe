!function(){"use strict";var e,t,c;e="/t/tr/lp/index.js"+window.location.search,(c=document.createElement("script")).src=e,c.async=t,document.head.appendChild(c)}();
